let posts = [];

function addPost() {
  const usernameInput = document.getElementById("username");
  const contentInput = document.getElementById("postContent");
  const imageInput = document.getElementById("imageInput");
  
  const username = usernameInput.value.trim();
  const content = contentInput.value.trim();
  
  if (!username || !content) {
    alert("Please enter name and post!");
    return;
  }
  
  const file = imageInput.files[0];
  
  // Function to create and save post
  function createPost(imageData = null) {
    const post = {
      user: username,
      text: content,
      time: new Date().toLocaleString(),
      image: imageData
    };
    
    posts.unshift(post);
    displayPosts();
    
    // Clear inputs after successful post
    usernameInput.value = "";
    contentInput.value = "";
    imageInput.value = "";
  }
  
  // If image exists
  if (file) {
    // Validate image type
    if (!file.type.startsWith("image/")) {
      alert("Please upload a valid image.");
      return;
    }
    
    const reader = new FileReader();
    
    reader.onload = function(e) {
      createPost(e.target.result);
    };
    
    reader.onerror = function() {
      alert("Error reading image file.");
    };
    
    reader.readAsDataURL(file);
  } else {
    createPost();
  }
}

function displayPosts() {
  const feed = document.getElementById("feed");
  feed.innerHTML = "";
  
  posts.forEach((p) => {
    const postDiv = document.createElement("div");
    
    postDiv.style.border = "px solid #ccc";
    postDiv.style.margin = "10px";
    postDiv.style.padding = "10px";
    postDiv.style.borderRadius = "10px";
    postDiv.style.backgroundColor = "darkred";
    postDiv.style.color = "azure";
    postDiv.style.boxShadow = "5px 5px white";
    postDiv.style.fontStyle = "italic";
    
    // Prevent undefined image issue
    const imageHTML = p.image ?
      `<img src="${p.image}" 
             style="max-width:100%; margin-top:10px; border-radius:8px;">` :
      "";
    
    postDiv.innerHTML = `
      <strong>${escapeHTML(p.user)}</strong><br>
      <small>${p.time}</small>
      <p>${escapeHTML(p.text)}</p>
      ${imageHTML}
    `;
    
    feed.appendChild(postDiv);
  });
}

// Prevent HTML injection
function escapeHTML(str) {
  return str
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}